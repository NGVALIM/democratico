//Nath�lia Gon�alves Calisto Valim de Souza
#include <iostream>
#include <fstream>
#include <locale.h>
using namespace std;

/*  */

typedef struct Candidato {
    string nome; // Nome do candidato
    int numero; // N�mero do candidato
    int votos; //Votos para o candidato
    Candidato *proximo = NULL; // Ponteiro para o pr�ximo candidato na lista
}no;

typedef struct { // Criando no para direcionar o inicio e o fim
	no *inicio, *fim;
	int total;
}filacandidato;

struct Eleitor {
    string nome; // Nome do candidato
    int titulo; // N�mero do candidato
    Eleitor *proximo = NULL; // Ponteiro para o pr�ximo eleitor na lista
};


void ifilacandidato(filacandidato *F);//iniciar fila para candidato
void entrarfila(filacandidato *F, struct nome, int numero);//entrando na fila nome e n�mero


int main() {

setlocale(LC_ALL, "Portuguese");
char nome(10);
int numero;
int op;


cout << "---------------Projeto: A festa da democracia---------------\n";
cout << "~~~~~~~~~~~~~~~~~~~~Bem vindo a ELEI��O...~~~~~~~~~~~~~~~~~~~~~~\n";
cout << "1 - Cadastro de CANDIDATOS \n";
cout << "2 - Cadastro de ELEITORES \n";
cout << "3 - Registro de VOTOS \n";
cout << "4 - Apura��o dos VOTOS \n";
cout << "5 - Encerrar \n";
cin>>op;




filacandidato candidato;	
ifilacandidato(&candidato);
entrarfila(&candidato, &nome, &numero);

	switch(op){
		case 1{
			
cout << "Digite o nome do candidato: " << endl;
cin >> no.nome;
cout << "Digite o n�mero do candidato" << endl;
cin >> no.numero;
filacandidato candidato;
break;
}
		case 2:
cout << "Digite o nome do eleitor: " << endl;
cin >> Eleitor.nome;
cout << "Digite o n�mero do t�tulo do eleitor" <<endl;
cin >> Eleitor.titulo;
}




return 0;
}

void ifilacandidato(filacandidato *F) {//iniciar fila para candidato
    F->inicio=NULL;
    F->fim=NULL;
    F->total=0;
}
void entrarfila(filacandidato *F, std::string *nome, int *numero)//entrando na fila nome e n�mero
{
    no *novo_no;
    novo_no=(no*)malloc(sizeof(no));
    /* se eu n�o conseguir criar o p � porque a mem�ria est� com espa�o cheio, 
	por isso n�o precisa da fun��o IsFull
	*/
    	novo_no->nome = *nome;
    	novo_no->numero = *numero;
    	novo_no->proximo = NULL;
    	if (F->inicio==NULL) // se for o primeiro a entrar na fila
		{
    		F->inicio = novo_no;
    		F->fim = novo_no;
    		novo_no->proximo = NULL;
    		F->total++;
    	}
    	else
		{// se j� tiver alguem na fila
			F->fim->proximo = novo_no;
			F->fim = novo_no;
			novo_no->proximo = NULL;
			F->total++;
		} 
	}
}
